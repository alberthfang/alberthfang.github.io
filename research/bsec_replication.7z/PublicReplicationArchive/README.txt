
**************************************
*
* Public replication archive for:
* Gerber, Alan S., Gregory A. Huber, Albert H. Fang, and Andrew Gooch. (Forthcoming)
* "Non-Governmental Campaign Communication Providing Ballot Secrecy Assurances Increases
*   Turnout: Results from Two Large Scale Experiments"
* Political Science Research and Methods
*
* Date: 03 January 2017
* Version 1.0
*
**************************************

This replication archive contains 8 files. Please create 2 subdirectories named "Tables" and "Figures" to store saved output.

DOCUMENTATION FILE:
1. This file (README.txt) documenting the files in the replication archive

DATA FILE:
2. PublicReplicationDataset.dta is the dataset (Stata 12 format) used by the analysis programs

PROGRAM FILES (Stata .do files):
3. 00_RunPrograms.do is a Stata .do file that executes the analyses for the paper, and executes 02_Analysis.do and 03_Appendix.do
4. 01_CreatePublicDataset.do is a Stata .do file that creates the public dataset (provided to show how the public dataset is created; does not run).
5. 02_Analysis.do is a Stata .do file that performs the analyses for all tables and figures reported in the main paper
6. 03_Appendix.do is a Stata .do file that performs the analyses for all tables and figures reported in the supplemental appendix

LOG FILES:
7. 02_Analysis.log is a log file showing the output from 02_Analysis.do
8. 03_Analysis.log is a log file showing the output from 03_Appendix.do